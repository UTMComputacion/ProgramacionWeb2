export class Categoria{
    nombre:string;
    descripcion:string; 
    constructor() {
        this.nombre = '';
        this.descripcion= '';
        }
}