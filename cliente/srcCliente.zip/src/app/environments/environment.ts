export const environment = {
    production: false,
    API_URI: "http://localhost:3000/api",
    };